package com.example.todo.controller;

import com.example.todo.model.Todo;
import com.example.todo.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TodoController {

    @Autowired
    private TodoService todoService;

    @RequestMapping("/")
    public String index(Model model) {
        model.addAttribute("todos", todoService.getTodos());
        return "index";
    }

    @PostMapping("/add")
    public String addTodo(@RequestParam String title) {
        todoService.addTodo(new Todo(title, false));
        return "redirect:/";
    }

    @PostMapping("/remove")
    public String removeTodo(@RequestParam int index) {
        todoService.removeTodo(index);
        return "redirect:/";
    }
}
